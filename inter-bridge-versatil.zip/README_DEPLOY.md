
Deploy no Render:

1. Enviar este projeto para o GitHub.
2. No Render → New Web Service → Importar do GitHub
3. Build Command: npm install
4. Start Command: npm start
5. Configurar Environment Variables:
   - INTER_CLIENT_ID
   - INTER_CLIENT_SECRET
   - INTER_CERT_B64
   - INTER_KEY_B64
   - INTER_BASE_URL = https://cdpj.partners.bancointer.com.br
6. Deploy :) 
